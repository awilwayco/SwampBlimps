#!/bin/bash

#Pings Pi
num1=$(ping -c 1 192.168.0.1 | tail -n 5 | head -n 1 | egrep "ttl=" | wc -l)

#Run Vision Code
#xdotool type "ping 192.168.0.1"
#xdotool type "./runVision1.sh"
xdotool type "echo \"Run Vision Code\""
xdotool key Return

#Move to Ping Screen
sleep 1
xdotool key "alt+Right" #&& xdotool key "alt+Down"

#Ping Pi
#sleep 1
#xdotool key "alt+Up"
#xdotool type "echo \"Pinging Pi\""
xdotool type "sleep 5; while [ \"$num1\" -ne 1 ]; do echo \"Pi not Found\"; sleep 1; done; echo \"Run Open Eyes Code\""
#while [ "$num1" -ne 1 ]; do echo \"Pi not Found\"; sleep 1; done
xdotool key Return

#Check ML
sleep 1
xdotool key "alt+Down"
xdotool key "alt+Left"
xdotool type "sleep 5; while [ \"$num1\" -ne 1 ]; do echo \"Pi not Found\"; sleep 1; done; sleep 5; echo \"Run ML Code\""
xdotool key Return

