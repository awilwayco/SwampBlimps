#/bin/bash

#Pings Pi
num1=$(ping -c 1 192.168.0.111 | tail -n 5 | head -n 1 | egrep "ttl=" | wc -l)
#num2=$(./../Viewers/checkML1.sh | egrep "nanosec: 0" | wc -l)
#Create screens
./createScreens.sh

#Boot Up Vision
./bootUpVision.sh

#Testing reboot
#./rebootVision.sh

#Verify if ML is broken
#num2=$(egrep "nanoseconds: 0.0" | wc -l)

#if [ 1 -eq 1 ]; then
#Wait until Pi is recognized
#while [ "$num1" -ne 1 ]; do; done

#sleep 1
#Open Blimp Eyes
#xdotool key "alt+Left" && xdotool key "alt+Down" && echo "Opening eyes"
#sleep 1
#Check ML
#xdotool key "alt+Right" && xdotool key "alt+Right" && echo "Checking ML"
