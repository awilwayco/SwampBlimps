#!/bin/bash

#Create screen (4 or 5 screens? 4 for now)
xdotool key "ctrl+shift+i"
sleep 1
xdotool key "ctrl+shift+e"
xdotool key "ctrl+shift+o"
#xdotool key "ctrl+shift+e"
sleep 1
xdotool key "alt+Left" #&& xdotool key "alt+Left"
xdotool key "ctrl+shift+o"
sleep 1
xdotool key "alt+Up"
