#!/bin/bash

xdotool key "Ctrl+C"
sleep 1
xdotool key "alt+Up"
sleep 1
xdotool key "Ctrl+C" && xdotool key "Ctrl+C"
sleep 1
xdotool type "Z"
sleep 1
xdotool key "Ctrl+C"
sleep 1
xdotool key "alt+Right"
sleep 1
xdotool key "Ctrl+C"
xdotool type "echo \"Closing eyes\"" && xdotool key Return
sleep 1
xdotool key "Alt+Left" 
