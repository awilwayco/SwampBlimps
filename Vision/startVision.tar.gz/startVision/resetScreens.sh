#!/bin/bash

sleep 1
xdotool key "alt+Down"
xdotool key "ctrl+shift+w"

sleep 1
xdotool key "alt+Right"
xdotool key "ctrl+shift+w"

sleep 1
xdotool key "alt+Right"
xdotool key "ctrl+shift+w"

#sleep 1
#xdotool key "alt+Right"
#xdotool key "ctrl+shift+w"
