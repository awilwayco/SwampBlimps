#!/bin/bash

./freePort.sh 5000
# Make a read only webpage eventually
# python3 Basestation/BS_Streamlit/Run.py
streamlit run --server.address 192.168.0.200 --server.port 5000 --server.headless true Basestation/BS_Streamlit/Main.py
#ros2 launch launch/Basestation_Streamlit.py
echo ""
echo "Exiting Program..."
