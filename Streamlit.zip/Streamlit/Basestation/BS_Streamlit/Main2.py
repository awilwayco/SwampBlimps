#!/usr/bin/env python3

"""
pip3 install pySerial
pip3 install easygui
sudo apt-get install python3-tk (to install tkinter, needed for easygui)
"""

# Python Packages
from threading import Thread
import time
import subprocess
import socket
import serial
import signal
import sys
import os
import requests

# ROS2 Packages
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Int64

# Streamlit Package
import streamlit as st
from streamlit import session_state as state

# from BlimpHandler import BlimpHandler

class ReadOnly(Node):

    def __init__(self):
        super().__init__('ReadOnly')
        self.auto_sub = self.create_subscription(Bool, '/Blimp1/auto', self.getAuto, 10)
        self.data = None

    def getAuto(self, msg):
        self.get_logger().info('Auto: "%s"' % msg.data)
        #data_placeholder.write("Auto: {}".format(msg.data))
        self.data = msg.data

    def getData(self):
        return self.data

@st.cache_resource
def initROS():
    rclpy.init()

@st.cache_resource
def createSub():
    return ReadOnly()

def is_rclpy_initialized():
    return rclpy.ok()

def send_ctrl_c():
    # Get the current process ID
    pid = os.getpid()

    # Send the Ctrl+C signal to the process
    os.kill(pid, signal.SIGINT)

def main(subscriber):

    # Start the Streamlit application
    st.title("Basestation")

    if 'auto_data' not in state:
        state.auto_data = None

    # Streamlit Data
    #global data_placeholder
    #data_placeholder = st.empty()

    while True:
        state.auto_data = subscriber.getData()
        print(state.auto_data)
        st.write("Auto:", state.auto_data)

        # Spin the subscriber node
        rclpy.spin(subscriber)

if __name__ == '__main__':

    if not is_rclpy_initialized():
        initROS()

    subscriber = createSub()

    try:
        # Run main
        main(subscriber)

    except ValueError:
        #send_ctrl_c()
        pass
        #subprocess.run(['python3', 'Basestation/BS_Streamlit/Run.py'])

    except KeyboardInterrupt:
        # Ctrl+C is pressed
        subscriber.destroy_node()
        rclpy.shutdown()
        st.stop()
