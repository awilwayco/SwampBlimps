#!/usr/bin/env python3

"""
pip3 install pySerial
pip3 install easygui
sudo apt-get install python3-tk (to install tkinter, needed for easygui)
"""

# Python Packages
from threading import Thread
import time
import subprocess
import socket
import serial
import signal
import sys
import os
import requests
import fcntl

# ROS2 Packages
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Int64
from test_msgs.srv import BasicTypes

# Streamlit Package
import streamlit as st
from streamlit import session_state as state

# from BlimpHandler import BlimpHandler

# Can change name of node to basestation later
class Listener(Node):

    def __init__(self):
        super().__init__('Listener')
        self.auto_sub = self.create_subscription(Bool, '/Blimp1/auto', self.getAuto, 10)
        self.data = None

    def getAuto(self, msg):
        #self.get_logger().info('Auto: "%s"' % msg.data)
        data_placeholder.write("Auto: {}".format(msg.data))
        self.data = msg.data

    def getData(self):
        return self.data

@st.cache_resource
def initROS():
    rclpy.init()

@st.cache_resource
def createSub():
    return Listener()

def is_rclpy_initialized():
    return rclpy.ok()

def send_ctrl_c():
    # Get the current process ID
    pid = os.getpid()

    # Send the Ctrl+C signal to the process
    os.kill(pid, signal.SIGINT)

def main(subscriber):

    # Start the Streamlit application
    st.title("Basestation")

    # Streamlit Data
    global data_placeholder
    data_placeholder = st.empty()

    # Path to the lock file
    lock_file = "/tmp/streamlit_lock"

    # Acquire an exclusive lock
    with open(lock_file, "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)

        # Spin the subscriber node
        rclpy.spin(subscriber)

        # Release the lock
        fcntl.flock(lock, fcntl.LOCK_UN)


if __name__ == '__main__':

    if not is_rclpy_initialized():
        initROS()

    subscriber = createSub()

    try:
        # Run main
        main(subscriber)

    except ValueError:
        #send_ctrl_c()
        pass
        #subprocess.run(['python3', 'Basestation/BS_Streamlit/Run.py'])

    except KeyboardInterrupt:
        # Ctrl+C is pressed
        subscriber.destroy_node()
        rclpy.shutdown()
        st.stop()
