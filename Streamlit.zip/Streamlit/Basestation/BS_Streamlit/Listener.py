import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
import streamlit as st
from functools import partial
class Listener(Node):
    def __init__(self):
        super().__init__('Listener')
        qos_profile = rclpy.qos.qos_profile_sensor_data
        self.subscriber_ = self.create_subscription(Bool, '/Blimp1/auto', partial(self.callback), qos_profile)
    def callback(msg):
        # Process the received message
        #self.get_logger().info(f'Received message: {msg.data}.')
        data = msg.data
        print("Received data:", data)

def main():
    rclpy.init()
    node = Listener()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()