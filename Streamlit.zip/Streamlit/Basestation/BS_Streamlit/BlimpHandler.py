# Imported Classes
from Blimp import Blimp
#from InputHandler import InputHandler
#from BlimpMapper import BlimpMapper
from ROS2Helper import ROS2Helper

# Imported Libraries
import time
import easygui
import serial

# ======================== Blimp Handler Class ======================== #
class BlimpHandler:

# =================== Blimp Handler Class Functions =================== #

    # ================ Initialization of Blimp Handler ================ #
    # Description #
    # Sets up UDP and initializes variables to default values
    def __init__(self):
        # Communication Initialization (ROS2)
        ROSLoopRate = 20
        self.ROS2Helper = ROS2Helper(ROSLoopRate, self)
        self.ROS2Helper.start()

        # Display Initialization
        self.display = None

        # List of Blimps
        self.blimps = []

        # Initialize dict storing indices of blimps
        self.blimpIndexMap = {}

        # Blimp Names and IPs
        self.blimpIPNameMap = {"192.168.0.101": "Spicy Hot Dog",
                               "192.168.0.102": "Waffle",
                               "192.168.0.103": "Apple",
                               "192.168.0.104": "Milk",
                               "192.168.0.105": "Pasta",

                               "192.168.0.100": "Silly Ahh",

                               "192.168.0.80": "Big Cup of Eggs",
                               "192.168.0.20": "Leg in a Cup",
                               "192.168.0.89": "I'm in a Cup",
                               "192.168.0.62": "My Cup of Eggs",
                               "192.168.0.86": "Pint of Eggs",
                               "192.168.0.14": "Stealthy Steve",
                               "BurnCreamBlimp":"Burn Cream Blimp",
                               "20": "Barometer"}

        """
        #Map of established connections (i.e. EC)
        self.blimpECMap = {"192.168.0.101": False,
                            "192.168.0.102": False,
                            "192.168.0.103": False,
                            "192.168.0.104": False,
                            "192.168.0.105": False,

                            "192.168.0.80": False,
                            "192.168.0.20": False,
                            "192.168.0.89": False,
                            "192.168.0.62": False,
                            "192.168.0.86": False,
                            "192.168.0.14": False,

                            "20": False}
        """

        # Hard-coded list of all blimps
        self.swampBlimps = {}

        for key in self.blimpIPNameMap:
            newBlimp = Blimp(key, self.blimpIPNameMap[key])
            self.swampBlimps[key] = newBlimp

        self.numNewBlimps = 0

        # Initialize Input Handler
        #self.inputHandler = InputHandler()

        # Initialize Blimp Mapper
        #self.blimpMapper = BlimpMapper(self, self.inputHandler)

        # Blimp States
        self.blimpStateStrings = {-1: "None",
                                  0: "searching",
                                  1: "approach",
                                  2: "catching",
                                  3: "caught",
                                  4: "goalSearch",
                                  5: "approachGoal",
                                  6: "scoringStart",
                                  7: "shooting",
                                  8: "scored"}

        self.lastBlimpAdded = 0
        self.blimpAddDelay = 5

        # Set Base Height
        self.baseBaroData = 0

        # Barometer Initialization
        self.baroPrioritizeUDP = False
        self.baroTimeout = 3  # seconds
        self.baroType = None
        self.lastBaroPrint = 0
        self.baroUDPLastReceivedTime = 0
        self.baroUDPLastReceivedValue = None
        self.baroSerialLastReceivedTime = 0
        self.baroSerialLastReceivedValue = None
        self.baroSerial = None

        # Try connecting to the Barometer
        try:
            self.baroSerial = serial.Serial('/dev/baro_0', 115200)
        except serial.SerialException:
            # Error
            print("Serial error!")

        # Plot Data
        self.plotData = {}

        # Initialize Total Number of Messages
        self.numMessages = 0

        # Initialize Last Checked Number of Messages
        self.lastCheckedNumMessages = 0

        # Initialize Last Loop Update
        self.lastUpdateLoop = 0

        # Initialize Global Targets
        self.globalTargets = False

        #self.addFakeBlimp(1000, "Fake Blimp 1000")

    # ====================== Close Blimp Handler ====================== #
    # Description #
    # Closes UDP
    def close(self):
        # Print Closing Message
        print("Closing BlimpHandler")

        # Close Communication (ROS2)
        self.ROS2Helper.close()

        # Print All Comms Closed
        print("Comms closed.")

    # ================== Set Display of Blimp Handler ================= #
    # Description #
    # Sets up the display and shows controllers
    # def setDisplay(self, display):
    #     # Set Display
    #     self.display = display

    # ================== Update Blimp Handler (Loop) ================== #
    # Description #
    # Loops to continuously check and update barometer height, dead blimps,
    # general blimp data, and wait time since last update
    def update(self):
        # Update Barometer Height
        #self.updateBaroHeight()
        # Update Input Handler
        #self.inputHandler.update()
        # Check for Dead Blimps
        # self.checkForDeadBlimps()
        # Update Blimp Mapper
        #self.blimpMapper.update()
        # Get Blimp Data
        # self.listen()
        # Update Blimp Data
        # self.sendDataToBlimps()
        #self.updateBlimpData()

        # Calculate and Print Wait Time
        waitTime = time.time() - self.lastUpdateLoop
        #if waitTime > 0.01:
            #print(waitTime)

        # Set Last Loop Update to current time
        self.lastUpdateLoop = time.time()

    # ======================= Add a Fake Blimp ======================== #
    # Description #
    # Creates and Returns a Temporary Blimp with an ID and Name
    def addFakeBlimp(self, ID, name):
        fakeBlimp = Blimp(ID, name)
        fakeBlimp.lastHeartbeatDetected = 99999999999999
        self.swampBlimps[ID] = fakeBlimp