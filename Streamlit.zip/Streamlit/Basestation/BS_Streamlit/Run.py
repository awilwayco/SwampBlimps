import socket
import subprocess
from threading import Thread

def is_port_in_use(port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("localhost", port))
        return False  # Port is available
    except OSError:
        return True  # Port is already in use

def find_available_port(start_port, end_port):
    for port in range(start_port, end_port + 1):
        if not is_port_in_use(port):
            return port
    return None  # No available port found

def mainWebpage():
    subprocess.run(["streamlit", "run", "Basestation/BS_Streamlit/Main.py", "--server.address", "192.168.0.200", "--server.port", str(available_port)])

def readOnlyWebpage():
    subprocess.run(["streamlit", "run", "Basestation/BS_Streamlit/Main2.py", "--server.address", "192.168.0.200", "--server.port", str(available_port)])

# Define the range of ports to search for availability
start_port = 1235
end_port = 8080

# Find the first available port
available_port = find_available_port(start_port, end_port)

if available_port is None:
    print("No available port found.")
else:
    subprocess.run(["streamlit", "run", "Basestation/BS_Streamlit/Main.py", "--server.port", str(available_port)])
